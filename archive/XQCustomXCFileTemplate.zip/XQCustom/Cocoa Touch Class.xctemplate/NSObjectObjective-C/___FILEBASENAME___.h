//___FILEHEADER___

___IMPORTHEADER_cocoaTouchSubclass___

NS_ASSUME_NONNULL_BEGIN

@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocoaTouchSubclass___

@property(nonatomic, copy) NSString *<#property1#>;

@property(nonatomic, assign) NSInteger <#property2#>;

@property(nonatomic, assign) float <#property3#>;

@end

NS_ASSUME_NONNULL_END
