//___FILEHEADER___

import UIKit

class ___FILEBASENAMEASIDENTIFIER___: ___VARIABLE_cocoaTouchSubclass___ {
    //Your own properties
    var variable1: Int = 0
    var variable2: String? // Optional if it would be nil
    var variable3: Double? // Optional if it would be nil
}
