//
//  FDETabBarController.h
//  Demon
//
//  Created by xuequan on 2020/1/29.
//  Copyright © 2020 xuequan. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FDETabBarController : UITabBarController

@end

NS_ASSUME_NONNULL_END
