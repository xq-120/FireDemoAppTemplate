//
//  FDEHomeViewController.h
//  Demon
//
//  Created by xuequan on 2020/1/29.
//  Copyright © 2020 xuequan. All rights reserved.
//

#import "FDEBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface FDEHomeViewController : FDEBaseViewController

@end

NS_ASSUME_NONNULL_END
